# 500-Greatest-Albums
Exploring Rolling Stone Magazine's list of "The 500 Greatest Albums of All Time."

If you just want to read my report, take a look at the HTML file, but if you would like to see my code, the Rmd file would be best.

I found the data on https://www.kaggle.com/notgibs/500-greatest-albums-of-all-time-rolling-stone. You'll be able to learn a bit more about the dataset on Kaggle's website. 

If you would like to see the list album, there's a link in my Rmd and HTML files, and here: http://www.rollingstone.com/music/lists/500-greatest-albums-of-all-time-20120531
